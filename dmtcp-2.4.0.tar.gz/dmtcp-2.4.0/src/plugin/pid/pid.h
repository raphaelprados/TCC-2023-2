#include "dmtcp.h"

// Defines DLSYM_DEFAULT and NEXT_FNC_DEFAULT
// Needed to handle GNU symbol versioning.
#include "dlsym_default.h"
