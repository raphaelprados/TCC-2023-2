source ../../../../../dmtcp_env.sh
source ../../../../../mpich2_env.sh
source ../../../../../slurm_env.sh