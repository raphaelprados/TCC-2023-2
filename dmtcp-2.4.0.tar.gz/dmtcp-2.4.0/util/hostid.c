#include <unistd.h>
#include <stdio.h>
void main()
{
  printf("%d\n", gethostid());
}
