#!/bin/bash

rm -Rf dmtcp_restart* ckpt_* 0_[cr]*
rm -Rf LOGS/*
rm -f set.[0-9].*